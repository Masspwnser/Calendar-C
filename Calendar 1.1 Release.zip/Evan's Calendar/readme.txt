Evan's Calendar App v1.1 (anti-spaghetti)
Simply open the .exe file to run the program.
I recommend you make a shortcut for it.

note: shhhh, it's not really a calendar, don't tell anyone